package com.Palak.onlineproductsapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Productdetails extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_productdetails);
    }
}
